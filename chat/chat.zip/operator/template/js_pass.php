<script type="text/javascript">
$(document).ready(function() {
	
	jQuery(document).ready(function(){
		jQuery("#pass").keyup(function() {
		  passwordStrength(jQuery(this).val());
		});
	});
						
});
</script>