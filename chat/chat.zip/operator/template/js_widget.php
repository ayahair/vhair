<!-- JavaScript for select all -->
<script type="text/javascript">
	ls.main_url = "<?php echo BASE_URL_ADMIN;?>";
	ls.orig_main_url = "<?php echo BASE_URL_ORIG;?>";
	ls.main_lang = "<?php echo JAK_LANG;?>";
</script>