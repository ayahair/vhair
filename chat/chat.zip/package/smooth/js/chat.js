function lcjak_popupChat(urlgo) {

  $('#lcjframesize').fadeOut();
  window.location = urlgo;
  return true;

}